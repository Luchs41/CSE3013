<?
	//board_write.php 파일로 이동
	echo("<meta charset='utf-8'>");
	echo("<a href=board_write.php>게시판 쓰기</a><br>");
	//board_read.php 파일로 이동
	echo("<a href=board_read.php>게시판 읽기</a>");
?>